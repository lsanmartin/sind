
This directory provides the classes which are necessary to support audio meta data
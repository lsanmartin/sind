# Text to Speech Examples

I already provided the text to speech examples a part of the webserver examples, but decided to to some more examples that demonstrate how to do TTS using the regular audio-tools output streams!

Please note in the readme of the example, I specify which additional library you need to install!
# AudioKit

These sketches work on the AI Thinker AudioKit or the LyraT Audio Boards. If you want to use them on any other board you usually just need to replace the AudioKitStream with an I2SStream!

In the subdirectories you find the test sketches that can be built on the desktop. 
For details [see the Wiki](https://github.com/pschatzmann/arduino-audio-tools/wiki/Running-an-Audio-Sketch-on-the-Desktop)

